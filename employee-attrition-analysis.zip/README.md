# Employee Attrition Analysis (End-to-End)

Understand **why employees leave** and **predict attrition risk** using a clean, reproducible pipeline and an interactive HR dashboard.

## 📦 Project Contents
- `data/synthetic_hr_attrition.csv` — synthetic dataset with realistic signals.
- `notebooks/01_eda_and_model.ipynb` — EDA → preprocessing → model training → export artifacts.
- `src/preprocess.py` — helpers for preprocessing & metrics.
- `models/` — saved `model.pkl` and `preprocessor.pkl` after running the notebook.
- `app/streamlit_app.py` — HR dashboard with KPIs, drilldowns, and a prediction form.
- `requirements.txt` — Python dependencies.
- `.github/workflows/ci.yml` — simple CI to lint and smoke-test data load.

> 🔁 You can replace the synthetic data with the **IBM HR Analytics Employee Attrition** dataset. Just drop the CSV into `data/` and update `--data-path` when running.

## 🚀 Quickstart

```bash
# 1) Create environment (Python 3.10+ recommended)
pip install -r requirements.txt

# 2) Train models & export artifacts via the notebook
# (Or run the scriptified cells in order to generate model.pkl and preprocessor.pkl)

# 3) Launch dashboard
streamlit run app/streamlit_app.py -- --data-path data/synthetic_hr_attrition.csv
```

## 🧠 What’s inside

- **EDA**: distributions, correlations, attrition by department/age/salary/tenure.
- **Models**: Logistic Regression & Random Forest (with class imbalance handling).
- **Metrics**: Accuracy, Precision, Recall, F1, ROC-AUC + confusion matrix.
- **Explainability**: global feature importance & partial dependence style summaries.
- **Dashboard KPIs**:
  - Overall Attrition Rate
  - Attrition by Department, Job Role, Age Band, Salary Band, Overtime
  - Predict individual attrition risk with a simple form

## 📁 Swap in a real dataset

- Replace `data/synthetic_hr_attrition.csv` with your CSV (must have a `Attrition` column of Yes/No).
- Update column names in `src/preprocess.py` if they differ.
- Re-run the notebook to regenerate artifacts.

## 💡 Publish to GitHub

1. Create a new repo on GitHub (public).
2. Push this folder:
   ```bash
   git init
   git add .
   git commit -m "Employee Attrition Analysis: E2E pipeline + dashboard"
   git branch -M main
   git remote add origin https://github.com/<your-username>/employee-attrition-analysis.git
   git push -u origin main
   ```
3. Use that URL as your LinkedIn/GitHub project link.

## 📝 License
MIT
