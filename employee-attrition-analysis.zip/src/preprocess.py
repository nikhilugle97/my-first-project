import pandas as pd
import numpy as np
from typing import Tuple, List, Dict

from sklearn.compose import ColumnTransformer
from sklearn.preprocessing import OneHotEncoder, StandardScaler
from sklearn.model_selection import train_test_split
from sklearn.metrics import accuracy_score, precision_score, recall_score, f1_score, roc_auc_score, confusion_matrix
from sklearn.impute import SimpleImputer

TARGET = "Attrition"

def split_features_target(df: pd.DataFrame, target: str = TARGET):
    X = df.drop(columns=[target])
    y = (df[target].astype(str).str.strip().str.title() == "Yes").astype(int)
    return X, y

def get_feature_groups(df: pd.DataFrame) -> Tuple[List[str], List[str]]:
    cat_cols = df.select_dtypes(include=["object","category","bool"]).columns.tolist()
    num_cols = df.select_dtypes(include=[np.number]).columns.tolist()
    if TARGET in cat_cols: cat_cols.remove(TARGET)
    if TARGET in num_cols: num_cols.remove(TARGET)
    return num_cols, cat_cols

def build_preprocessor(num_cols: List[str], cat_cols: List[str]):
    num_pipe = ("num", SimpleImputer(strategy="median"), num_cols)
    cat_pipe = ("cat", OneHotEncoder(handle_unknown="ignore", sparse_output=False), cat_cols)
    pre = ColumnTransformer([num_pipe, cat_pipe], remainder="drop")
    return pre

def train_valid_split(X, y, test_size=0.2, random_state=42):
    return train_test_split(X, y, test_size=test_size, random_state=random_state, stratify=y)

def basic_metrics(y_true, y_pred, y_proba=None) -> Dict[str, float]:
    out = {
        "accuracy": accuracy_score(y_true, y_pred),
        "precision": precision_score(y_true, y_pred, zero_division=0),
        "recall": recall_score(y_true, y_pred, zero_division=0),
        "f1": f1_score(y_true, y_pred, zero_division=0),
    }
    if y_proba is not None:
        try:
            out["roc_auc"] = roc_auc_score(y_true, y_proba)
        except Exception:
            pass
    return out

def confusion(y_true, y_pred):
    return confusion_matrix(y_true, y_pred).tolist()
