import argparse
from pathlib import Path

import pandas as pd
import numpy as np
import streamlit as st
import plotly.express as px
from joblib import load

st.set_page_config(page_title="Employee Attrition Dashboard", layout="wide")

def load_artifacts():
    model_path = Path("models/model.pkl")
    if model_path.exists():
        try:
            model = load(model_path)
            return model
        except Exception:
            return None
    return None

def kpi_cards(df):
    attr_rate = (df["Attrition"].str.title()=="Yes").mean()
    total = len(df)
    overtime_rate = (df["OverTime"].str.title()=="Yes").mean()
    avg_income = df["MonthlyIncome"].mean()

    c1, c2, c3, c4 = st.columns(4)
    c1.metric("Attrition Rate", f"{attr_rate*100:.1f}%")
    c2.metric("Employees", f"{total}")
    c3.metric("Overtime %", f"{overtime_rate*100:.1f}%")
    c4.metric("Avg Monthly Income", f"{avg_income:,.0f}")

def section_attrition_breakdowns(df):
    st.subheader("Attrition Breakdown")
    c1, c2 = st.columns(2)
    by_dept = df.groupby("Department")["Attrition"].apply(lambda s: (s.str.title()=="Yes").mean()).reset_index(name="AttritionRate")
    fig1 = px.bar(by_dept, x="Department", y="AttritionRate", title="By Department")
    c1.plotly_chart(fig1, use_container_width=True)

    # Age bands
    bins = [18,25,30,35,40,45,50,60]
    labels = [f"{bins[i]}-{bins[i+1]-1}" for i in range(len(bins)-1)]
    tmp = df.copy()
    tmp["AgeBand"] = pd.cut(tmp["Age"], bins=bins, labels=labels, right=False)
    by_age = tmp.groupby("AgeBand")["Attrition"].apply(lambda s: (s.str.title()=="Yes").mean()).reset_index(name="AttritionRate")
    fig2 = px.line(by_age, x="AgeBand", y="AttritionRate", markers=True, title="By Age Band")
    c2.plotly_chart(fig2, use_container_width=True)

    c3, c4 = st.columns(2)
    by_role = df.groupby("JobRole")["Attrition"].apply(lambda s: (s.str.title()=="Yes").mean()).reset_index(name="AttritionRate").sort_values("AttritionRate", ascending=False)
    fig3 = px.bar(by_role, x="JobRole", y="AttritionRate", title="By Job Role")
    c3.plotly_chart(fig3, use_container_width=True)

    # Salary bands
    tmp["SalaryBand"] = pd.qcut(tmp["MonthlyIncome"], q=5, duplicates="drop")
    by_sal = tmp.groupby("SalaryBand")["Attrition"].apply(lambda s: (s.str.title()=="Yes").mean()).reset_index(name="AttritionRate")
    fig4 = px.bar(by_sal, x="SalaryBand", y="AttritionRate", title="By Salary Band")
    c4.plotly_chart(fig4, use_container_width=True)

def prediction_form(df, model):
    st.subheader("Predict Individual Attrition Risk")
    sample = df.sample(1, random_state=1).drop(columns=["Attrition"]).iloc[0].to_dict()
    with st.form("predict_form"):
        cols = st.columns(3)
        num_fields = ["Age","MonthlyIncome","DistanceFromHome","TotalWorkingYears","YearsAtCompany","JobSatisfaction","EnvironmentSatisfaction","WorkLifeBalance","PerformanceRating","NumCompaniesWorked","TrainingTimesLastYear","PercentSalaryHike","StockOptionLevel"]
        cat_fields = [c for c in df.columns if df[c].dtype == 'object' and c != "Attrition"]
        user_input = {}
        for i, key in enumerate(num_fields):
            with cols[i % 3]:
                user_input[key] = st.number_input(key, value=float(sample.get(key, 0)), step=1.0)
        for i, key in enumerate(cat_fields):
            with cols[(i + len(num_fields)) % 3]:
                options = sorted(df[key].astype(str).unique().tolist())
                user_input[key] = st.selectbox(key, options, index=options.index(str(sample.get(key, options[0]))))
        submitted = st.form_submit_button("Predict")
    if submitted:
        x = pd.DataFrame([user_input])
        try:
            proba = model.predict_proba(x)[:,1][0]
            st.success(f"Estimated Attrition Risk: {proba*100:.1f}%")
        except Exception as e:
            st.error("Model not available or failed to score. Try training first via the notebook.")
            st.exception(e)

def main():
    parser = argparse.ArgumentParser()
    parser.add_argument("--data-path", type=str, default="data/synthetic_hr_attrition.csv")
    args, unknown = parser.parse_known_args()

    data_path = Path(args.data_path)
    if not data_path.exists():
        st.error(f"Data file not found at {data_path}. Update --data-path.")
        st.stop()

    df = pd.read_csv(data_path)
    st.title("Employee Attrition Dashboard")
    kpi_cards(df)

    with st.expander("Filters"):
        col1, col2, col3 = st.columns(3)
        dept = col1.multiselect("Department", sorted(df["Department"].unique()), default=sorted(df["Department"].unique()))
        role = col2.multiselect("JobRole", sorted(df["JobRole"].unique()), default=sorted(df["JobRole"].unique()))
        ot = col3.multiselect("OverTime", sorted(df["OverTime"].unique()), default=sorted(df["OverTime"].unique()))
        mask = df["Department"].isin(dept) & df["JobRole"].isin(role) & df["OverTime"].isin(ot)
        df_f = df[mask].copy()

    section_attrition_breakdowns(df_f)

    model = load_artifacts()
    prediction_form(df, model)

if __name__ == "__main__":
    main()
